# Comment User Badges

A free plugin that displays a user badge below comments depending on the commentor's role.